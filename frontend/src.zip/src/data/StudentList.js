const StudentList = () => {
    return ( 
       {
         fullName: "Reem zahraman",
         phone: "000000",
         email: "Reem@example.com",
         country: "Lebanon",
         language: "English",
         level: "Beginner"
       }
     );
}
 
export default StudentList;