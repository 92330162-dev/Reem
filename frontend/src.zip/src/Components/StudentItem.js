const StudentItem = ({fullName,phone,email,country,language,level}) => {
    return ( 
        <tr>
            <td>{fullName}</td>
            <td>{phone}</td>
            <td>{email}</td>
            <td>{country}</td>
            <td>{language}</td>
            <td>{level}</td>
        </tr>
     );
}
 
export default StudentItem;