import "./Header.css"

const Header = () => {
    return (  
     <div>
      <header>
    <nav>
      <ul class="menu">
        <li><a href="index.html">Home</a></li>
        <li><a href="languages.html">Languages</a></li>
        <li><a href="register.html">Register</a></li>
        <li><a href="language-management.html">Lang. Management</a></li> 
        <li><a href="about.html">About</a></li>
      </ul>
    </nav>
  </header>
     </div>
    );
}
 
export default Header;