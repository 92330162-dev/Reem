import "./Footer.css"
const Footer = () => {
    return ( 
        <div>
           <footer> <p>&copy; 2025 Language Learning Buddy. All rights reserved.</p></footer>
        </div>
     );
}
 
export default Footer;