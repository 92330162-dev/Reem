import Home from "./pages/Home";
import Languages from './pages/Languages';
import Register from "./pages/Register";
import Language_management from "./pages/LanguageManagement";
import About from './pages/About';

import {BrowserRouter as Router , Routes , Route } from 'react-router-dom'; 

function App() {
 
  return (
    <div className="App">
      <Router>
        
            <Routes>
                <Route path ="/" excat Component={Home}/>
                <Route path ="/languages" excat Component={Languages}/>
                <Route path ="/register" excat Component={Register}/>
                <Route path ="/language-management" excat Component={Language_management}/>
                <Route path ="/about" excat Component={About}/>
            </Routes>
        </Router>
        
    </div>
  );
}

export default App;
