import { useState } from "react";
import NavBar from "../Components/NavBar";
import Footer from "../Components/Footer";

const Language_management = () => {

    const [languages, setLanguages] = useState([]);
    const [formData, setFormData] = useState({
        langName: "",
        langFlag: "",
        langSpeakers: "",
        langInfo: ""
    });
    const [editIndex, setEditIndex] = useState(-1);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if (editIndex === -1) {
            setLanguages([...languages, formData]);
        } else {
            const updated = [...languages];
            updated[editIndex] = formData;
            setLanguages(updated);
            setEditIndex(-1);
        }
        setFormData({ langName: "", langFlag: "", langSpeakers: "", langInfo: "" });
    }


    return (
        <div className="App">
            <NavBar/>
            <main id="language-management" className="page">
                <div className="management-container">

                    {/* Form */}
                    <div className="form-container">
                        <h2>➕ Add/Edit Language</h2>
                        <form id="languageForm" onSubmit={handleSubmit}>
                            <div className="form-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>

                                <div className="form-group">
                                    <label htmlFor="langName">Language Name: </label>
                                    <input type="text" id="langName" name="langName" required
                                        placeholder="e.g., Klingon" value={formData.langName} onChange={handleChange}/>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="langFlag">Flag/Symbol: </label>
                                    <input type="text" id="langFlag" name="langFlag" required
                                        placeholder="e.g., 🏴" value={formData.langFlag} onChange={handleChange}/>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="langSpeakers">Speakers: </label>
                                    <input type="text" id="langSpeakers" name="langSpeakers" required
                                        placeholder="e.g., 500,000" value={formData.langSpeakers} onChange={handleChange}/>
                                </div>

                                <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                                    <label htmlFor="langInfo">Description/Info: </label>
                                    <textarea id="langInfo" name="langInfo" rows="3" required
                                        placeholder="Brief description of the language." value={formData.langInfo} onChange={handleChange}/>
                                </div>

                            </div>

                            <div className="form-actions">
                                <button type="submit" id="langSubmitBtn" className="submit-btn">
                                    {editIndex === -1 ? "Add Language" : "Update Language"}
                                </button>
                                {editIndex !== -1 && (
                                    <button type="button" id="langCancelEditBtn" className="cancel-btn" >
                                        Cancel Edit
                                    </button>
                                )}
                            </div>
                        </form>
                    </div>

                    {/* Table */}
                    <div className="table-container">
                        <h2>📋 Managed Languages</h2>
                        <table id="languagesManagementTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Flag</th>
                                    <th>Name</th>
                                    <th>Speakers</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {languages.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" className="no-data">No languages defined yet</td>
                                    </tr>
                                ) : (
                                    languages.map((lang, key) => (
                                        <tr key={key}>
                                            <td>{key + 1}</td>
                                            <td>{lang.langFlag}</td>
                                            <td>{lang.langName}</td>
                                            <td>{lang.langSpeakers}</td>
                                            <td>
                                                <button className="update-btn" >Edit</button>
                                                <button className="delete-btn">Delete</button>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>

                </div>
            </main>
            <Footer/>
        </div>
    );
}

export default Language_management;
