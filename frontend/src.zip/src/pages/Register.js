import { useState } from "react";
import NavBar from "../Components/NavBar";
import Footer from "../Components/Footer";
import '../assets/register.css';

const Register = () => {
    const [StudentList, setStudents] = useState([]);
    //store thedata of the user
    const [formData, setFormData] = useState({
        fullName: "",
        phone: "",
        email: "",
        country: "",
        language: "",
        level: ""
    });

    //bt3ml update wa2t luser byektob chi
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    
    const handleSubmit = (e) => {
        e.preventDefault();
        setStudents([...StudentList, formData]); 
        setFormData({      //btfadde lechyayale 3abayneha ba3d ma tn2eon 3l table
            fullName: "",
            phone: "",
            email: "",
            country: "",
            language: "",
            level: ""
        });
    };

    return (
        <div className="App">
            <NavBar />

            <main id="register" className="page">
                <div className="management-container">

                    
                    <div className="form-container">
                        <h2>📝 Register to Learn a Language</h2>
                        <form onSubmit={handleSubmit}>
                            <div className="form-grid">
                                {/*Input*/}
                                <div className="form-group">
                                    <label>Full Name:</label>
                                    <input type="text" name="fullName" required placeholder="Full Name"
                                        value={formData.fullName} onChange={handleChange} />
                                </div>

                                <div className="form-group">
                                    <label>Phone number:</label>
                                    <input type="tel" name="phone" required placeholder="Phone Number"
                                        value={formData.phone} onChange={handleChange} />
                                </div>

                                <div className="form-group">
                                    <label>Email:</label>
                                    <input type="email" name="email" required placeholder="Email"
                                        value={formData.email} onChange={handleChange} />
                                </div>


                               {/* Selects */}
                               <div className="form-group">
                                    <select name="country" value={formData.country} onChange={handleChange} required>
                                        <option value="">Select Country</option>
                                        <option value="United States">United States</option>
                                        <option value="United Kingdom">United Kingdom</option>
                                        <option value="Canada">Canada</option>
                                        <option value="Australia">Australia</option>
                                        <option value="Germany">Germany</option>
                                        <option value="France">France</option>
                                        <option value="Spain">Spain</option>
                                        <option value="Italy">Italy</option>
                                        <option value="Japan">Japan</option>
                                        <option value="China">China</option>
                                        <option value="India">India</option>
                                        <option value="Brazil">Brazil</option>
                                        <option value="Mexico">Mexico</option>
                                        <option value="Lebanon">Lebanon</option>
                                        <option value="Egypt">Egypt</option>
                                        <option value="Saudi Arabia">Saudi Arabia</option>
                                        <option value="UAE">United Arab Emirates</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>

                                <div className="form-group">
                                    <select name="language" value={formData.language} onChange={handleChange} required>
                                        <option value="">Select Language</option>
                                        <option value="English">English</option>
                                        <option value="Spanish">Spanish</option>
                                        <option value="French">French</option>
                                        <option value="German">German</option>
                                        <option value="Italian">Italian</option>
                                        <option value="Japanese">Japanese</option>
                                        <option value="Chinese">Chinese</option>
                                        <option value="Arabic">Arabic</option>
                                        <option value="Russian">Russian</option>
                                        <option value="Portuguese">Portuguese</option>
                                        <option value="Korean">Korean</option>
                                        <option value="Hindi">Hindi</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>

                                <div className="form-group">
                                    <select name="level" value={formData.level} onChange={handleChange} required>
                                        <option value="">Select Level</option>
                                        <option value="Beginner">Beginner</option>
                                        <option value="Elementary">Elementary</option>
                                        <option value="Intermediate">Intermediate</option>
                                        <option value="Advanced">Advanced</option>
                                        <option value="Native">Native</option>
                                    </select>
                                </div>

                            </div>

                            <div className="form-actions">
                                <button type="submit" className="update-btn">Register</button>
                            </div>
                        </form>
                    </div>

                    {/* Table Section */}
                    <div className="table-container">
                        <h2>📊 Registered Students</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Country</th>
                                    <th>Language</th>
                                    <th>Level</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {StudentList.length === 0 ? (
                                    <tr>
                                        <td className="no-data" colSpan="7" style={{ textAlign: "center", fontStyle: "italic" }}>
                                            No students registered yet
                                        </td>
                                    </tr>
                                ) : (
                                    StudentList.map((StudentItem, key) => (
                                        <tr key={key}>
                                            <td>{key + 1}</td>
                                            <td>{StudentItem.fullName}</td>
                                            <td>{StudentItem.phone}</td>
                                            <td>{StudentItem.email}</td>
                                            <td>{StudentItem.country}</td>
                                            <td>{StudentItem.language}</td>
                                            <td>{StudentItem.level}</td>
                                            <td>
                                                <button className="update-btn">Edit</button>
                                                <button className="delete-btn">Delete</button>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>

                </div>
            </main>

            <Footer />
        </div>
    );
};

export default Register;